package org.eventer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventerApplicationTests {

	@Test
	void contextLoads() {
	}

}
